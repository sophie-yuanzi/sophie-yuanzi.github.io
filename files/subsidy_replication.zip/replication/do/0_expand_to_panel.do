/*==============================================================================
* File name:     0_expand_to_panel.do
* Date written:  April 9, 2026
* Date revised:  April 9, 2026

* Key logic:
*   - Year range per policy: max(start_year, 2001) to min(end_year, 2022) as
      the notifications reports detailed information of policies from 2001 to 2022.
*   - Each year is assigned to the corresponding notification_circle
*   - If policy starts before its earliest circle: extend that circle back
*     (e.g. start_year=2003, earliest circle=2005-2008 → 2003-2004 use 2005-2008)
*   - If policy ends after its latest circle: extend that circle forward
*     (e.g. end_year=2010, latest circle=2005-2008 → 2009-2010 use 2005-2008)
*   - Gaps between circles: manually filled by checking the original document
*
==============================================================================*/

clear all 
set more off 

//change the directory
pwd
cd .../data


//----------------------------------------------------------------------
// (1) Parse circle and policy year boundaries
//----------------------------------------------------------------------

use subsidy_data, clear

// Circle start and end years
gen circle_start = real(substr(notification_circle, 1, 4))
gen circle_end   = real(substr(notification_circle, 6, 4))

// Policy year range: cap to data coverage (2001–2022)
destring start_year, replace
gen end_num = real(end_year)
replace end_num = 2022 if end_year == "on-going"   // treat ongoing as active through 2022

gen panel_start = max(start_year, 2001)
gen panel_end   = min(end_num,   2022)


//----------------------------------------------------------------------
// (2) Determine effective year range per circle row
//----------------------------------------------------------------------

// Per-policy earliest and latest circle bounds
bysort id_policy: egen min_circle_start = min(circle_start)
bysort id_policy: egen max_circle_end   = max(circle_end)

gen eff_start = circle_start
gen eff_end   = circle_end

// Extend earliest circle back if policy starts before that circle
replace eff_start = panel_start ///
    if circle_start == min_circle_start & panel_start < circle_start

// Extend latest circle forward if policy ends after that circle
replace eff_end = panel_end ///
    if circle_end == max_circle_end & panel_end > circle_end

// Cap all circles to panel range
replace eff_start = max(eff_start, panel_start)
replace eff_end   = min(eff_end,   panel_end)

// Drop circles that fall completely outside policy's active range
drop if eff_start > eff_end


//----------------------------------------------------------------------
// (3) Expand to id_policy × year
//----------------------------------------------------------------------

gen n_years = eff_end - eff_start + 1
expand n_years
bysort id_policy notification_circle (eff_start): gen year = eff_start + _n - 1

drop circle_start circle_end min_circle_start max_circle_end ///
     eff_start eff_end n_years end_num panel_start panel_end


//----------------------------------------------------------------------
// (4) Manually fill gaps between circles
//     e.g. policy has circles 2017-2018 and 2021-2022 but active 2018-2021
//     → years 2019-2020 get filled using 2021-2022's variables according to orginal document
//----------------------------------------------------------------------

// Flag where gaps will be (notification_circle is already populated for real rows)
// tsfill adds new rows with missing values for all other variables
xtset id_policy year
tsfill

// Flag gap-filled rows for manual review
gen manual_check_expand = mi(notification_circle)
label var manual_check_expand "1 = year fell in gap between circles, variables carried forward"

// Carry forward circle-level variables into gap years
gsort id_policy -year
foreach var in notification_circle title authority D_local province ///
               start_year end_year form objective sector {
    by id_policy: replace `var' = `var'[_n-1] ///
        if manual_check_expand == 1
}


//----------------------------------------------------------------------
// (5) Final ordering and save
//----------------------------------------------------------------------

drop manual_check_expand
tostring start_year, replace
sort id_policy year
order id_policy year notification_circle title authority D_local province ///
      start_year end_year form objective sector
	  
save subsidy_data_panel, replace
