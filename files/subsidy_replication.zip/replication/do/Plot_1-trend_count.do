/*==============================================================================
* File name:     1-Plot.do
* Date written:  August 11, 2024
* Date revised:  April 9, 2026
*
==============================================================================*/


clear all 
set more off 

//change the directory
pwd
cd .../data



//------------------------------------------------------------------
// (1) Plot 1a: Policies Present and Newly Introduced by Year
//------------------------------------------------------------------

// Step 1: Generate yearly data
use subsidy_data_panel, clear  // Replace 'your_dataset' with your actual dataset name

// Step 2: Count policies present each year
bysort year: gen total_policies = _N

// Step 3: Identify newly introduced policies
gen local_policy = (D_local==1)
bysort year: egen new_policies = sum(local_policy)


// Step 4: Collapse data to yearly level
collapse (first) total_policies new_policies, by(year)

// Step 5: Create the bar graph with overlapping bars and no gaps

replace total_policies=total_policies-new_policies if year<2015
replace new_policies=0 if year<2015
twoway (bar total_policies year, color(black%20)) ///
       (bar new_policies year, color(black%60)), ///
       legend(order(1 "Central"  2 "Local")  size(small) row(1) region(lcolor(black)) pos(6)) ///
       ytitle("Number of Subsidies", size(large)) ///
       xlabel(2000(5)2022, valuelabel angle(45)) ///
       xtitle("Year", size(large)) ///
       graphregion(color(white)) ///
       ylabel(0(200)600, angle(horizontal)) ///
	   xline(2015, lcolor(black%80) lpattern(dash))  ///
       name(g1, replace)





//----------------------------------------------------------------------
// (2) Plot 1b: subsidies value over year
//----------------------------------------------------------------------

// Step 1: Merge value data
use subsidy_data_panel, clear  
merge 1:1 id_policy year using ./subsidy_value, keep(3) nogen

keep id_policy D_local year value


// Step 2: Collapse data to yearly level and adjust the data
collapse (sum) total_value = value, by(year D_local)
replace total_value = total_value/1000

// Step 3: Calculate value for local governments and central government
reshape wide total_value, i(year) j(D_local)
replace total_value1 = 0 if total_value1 == .
gen total_value = total_value0 + total_value1
drop if total_value == 0 | total_value == .

// Step 4: Merge with GDP data and compute shares 
merge 1:1 year using ./other_data/China_gdp_00_23, keep(3) nogen
replace gdp = gdp/10    //adjust unit to billion RMB, same as subsidy data
gen percentage = total_value/gdp*100   //report value in percentage points 


// Step 5: Create the bar graph with stacked bars and no gaps
twoway (bar total_value year, color(black%20) yaxis(1)) ///
       (bar total_value1 year, color(black%60) yaxis(1)) ///
       (connected percentage year, mcolor(black%60) msize(vsmall) lcolor(black%60) yaxis(2)), ///
	   legend(order(1 "Central"  2 "Local")  size(small) row(1) region(lcolor(black)) pos(6)) ///
       xlabel(2000(5)2022, valuelabel angle(45)) ///
       ylabel(, angle(horizontal) axis(1)) ///
       ylabel(, angle(horizontal) axis(2)) ///
       ytitle("Total Subsidy Values (Billion RMB)", axis(1) size(large)) ///
       ytitle("As Share of China's GDP (%)", axis(2)  size(large)) ///
       xtitle("Year", size(large)) ///
	   xline(2015, lcolor(black%80) lpattern(dash))  ///
       graphregion(fcolor(white)) ///
       name(g2, replace)

	   
graph combine g1 g2, ///
    col(2) ///
    imargin(medium) ///
    graphregion(color(white)) ///
    iscale(*0.9) ///
    note("                        (a) Number of Subsidies                                       (b) Total Values", size(medium) span) 
    
	
graph export ../figs/1_combination_final.png, width(3200) height(1800) replace

