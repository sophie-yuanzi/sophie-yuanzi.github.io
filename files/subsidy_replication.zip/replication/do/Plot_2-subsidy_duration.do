*==============================================================================
* File name:     2-Plot.do
* Date written:  September 9, 2024
* Date revised:  April 9, 2026
* 
* ==============================================================================*/

clear all 
set more off 

//change the directory
pwd
cd ../data


//---------------------------------------------------------------------- 
// (1) Plot 2a: The replationship between the policy count and the GDP per capita
//----------------------------------------------------------------------
use ./other_data/subsidy_worldwide, clear 

local highlighted_countries `""CHN", "USA", "EU", "JPN", "KOR""'
local other_highlighted `""USA", "EU""'

// Different positions for overlapped labels
local label_right `""CAN", "MEX", "ARG", "SYC", "ESP", "SVK", "PRT", "FRA", "HND""'
local label_down `""ISR", "AUT","KHM""'


// Plot Graph
twoway (scatter lnum lGDP if !inlist(Country, `highlighted_countries')&!inlist(Country, `label_down')&!inlist(Country, `label_right'), mlabposition(3) msize(small) mlabel(Country) mlabcolor(black) mlabsize(vsmall) mcolor(grey%20)) ///
       (scatter lnum lGDP if inlist(Country, `label_right'), mlabposition(9) msize(small) mlabel(Country) mlabcolor(black) mlabsize(vsmall) mcolor(grey%20)) ///
	   (scatter lnum lGDP if inlist(Country, `label_down'), mlabposition(6) msize(small) mlabel(Country) mlabcolor(black) mlabsize(vsmall) mcolor(grey%20)) ///
       (scatter lnum lGDP if inlist(Country, `other_highlighted'), mlabposition(3) msize(small) mlabel(Country) mlabcolor(blue) mlabsize(vsmall) mcolor(blue)) ///
	   (scatter lnum lGDP if Country == "JPN", mlabposition(2) msize(small) mlabel(Country) mlabcolor(black) mlabsize(vsmall) mcolor(grey%20)) ///
	   (scatter lnum lGDP if Country == "KOR", mlabposition(4) msize(small) mlabel(Country) mlabcolor(black) mlabsize(vsmall) mcolor(grey%20)) ///
       (scatter lnum lGDP if Country == "CHN", mlabposition(3) msize(small) mlabel(Country) mlabcolor("196 81 97") mlabsize(vsmall) mcolor("196 81 97")) ///
       (lfit lnum lGDP , mlabposition(3) msize(small) color(black)), ///
       ytitle("Number of Subsidies", size(large)) ///
       xtitle("GDP Per Capita (Thousand Dollars)", size(large)) ///
       xlabel(1 "2.72" 2 "7.39" 3 "20.09" 4 "54.60" 5 "148.41", format(%9.2f) valuelabel angle(horizontal)) ///
       ylabel(0 "1" 2 "7" 4 "55" 6 "403" , valuelabel angle(horizontal)) ///
       graphregion(fcolor(white)) ///
       legend(on order(- " " - " ") size(vsmall) pos(6) ring(1) region(lcolor(white) fcolor(white)) symxsize(0)) ///
       name(g1, replace)

	
//---------------------------------------------------------------------- 
// (2) Plot 2b: The duration of subsidies
//----------------------------------------------------------------------
	
// In this part, I separate the on-going policies (whose end-year are still "present" in 2022)

use subsidy_data_panel, clear
gen D_present_in_2022 = 1 if end_year == "on-going"
keep id_policy D_local start_year end_year D_present_in_2022
duplicates drop 
keep if D_local == 0
replace end_year = "2022" if end_year == "on-going"
destring start_year, replace
destring end_year, replace
gen duration = end_year - start_year + 1
summarize duration, detail
replace duration = 20 if duration >= 20 // For simplify, I conclude all the headings which are effective for more than 20 years.

// Count the number of IDs for each duration
collapse (count) id_count=id, by(duration D_present_in_2022)

replace D_present_in_2022 = 0 if D_present_in_2022 == .
reshape wide id_count, i(duration) j(D_present_in_2022)
replace id_count1 = 0 if id_count1 == .
gen id_count = id_count0 + id_count1
gen y0 = 0


// Sort by count in descending order
gsort -id_count

// Calculate percentages
egen total = sum(id_count)
gen percentage = id_count / total * 100

// Create a new variable with percentage and % sign
gen percentage_label = string(percentage, "%9.1f") + "%"



twoway (rbar id_count0 y0 duration, barwidth(0.8) color(gs8)) ///   
       (rbar id_count id_count0 duration, barwidth(0.8) color(gs12)) ///
       (scatter id_count duration, msymbol(none) mlabel(percentage_label) mlabposition(12) mlabsize(vsmall) mlabcolor(black)), ///
       ylabel(0(10)35, angle(horizontal)) ///
       xlabel(1(1)19 20 ">=20", labsize(small)) ///
       ytitle("Number of Subsidies", size(large)) ///
       xtitle("Duration(Years)", size(large)) ///
       graphregion(fcolor(white)) ///
       legend(order(1 "Completed" 2 "On-going") size(small) pos(6) ring(1) rows(1) region(lcolor(black))) ///
       name(g2, replace)



graph combine g1 g2, ///
    col(2) ///
    imargin(medium) ///
    graphregion(color(white)) ///
    iscale(*0.9) ///
    note("                      (a) International Comparison                          (b) Duration of Chinese Programs", size(medium) span) 
    
	
	
graph export ../figs/2_combination_final.png, width(3200) height(1800) replace
