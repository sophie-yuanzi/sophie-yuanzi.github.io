*==============================================================================
* File name:     3-Plot.do
* Date written:  September 9, 2024
* Date revised:  April 9, 2026
* 
*==============================================================================*/

clear all 
set more off 

//change the directory
pwd
cd ../data


//------------------------------------------------------------------
// (1) Split the objective variable
//------------------------------------------------------------------

use subsidy_data_panel, clear 

// Split the 'objective' variable and reshape
split objective, parse(; )
keep id_policy D_local year objective*
drop objective
reshape long objective, i(id_policy D_local year) j(j)


// Clean up the data
drop if objective == ""
drop j
replace objective =strltrim(objective)
save temp, replace


//------------------------------------------------------------------
// (2) Plot 3a: Year 2001 (Central)
//------------------------------------------------------------------

gen id=1 
keep if year==2001
drop if D_local==1 

// Count the number of IDs for each objective
collapse (sum) id_count=id, by(objective)

// Sort by count in descending order
gsort -id_count

// Calculate percentages
egen total = sum(id_count)
gen percentage = id_count / total * 100

// Generate a numeric identifier for each objective
gen objective_id = _n

// Keep the first 7 objectives
drop if objective_id > 10

// Add value labels to the x-axis
forvalues i = 1/`=_N' {
    label define objective_lbl `i' `"`=objective[`i']'"', add
}
label values objective_id objective_lbl

// Create a new variable with percentage and % sign
gen percentage_label = string(percentage, "%9.2f") + "%"


// Create the graph with percentage labels including % sign
twoway (bar id_count objective_id, barwidth(0.6) color(gs8) hori) ///  
       (scatter objective_id id_count, msymbol(none) mlabel(percentage_label) mlabposition(3) mlabsize(small) mlabcolor(black)), ///
       xlabel(0(10)30, angle(horizontal)) ///
       xscale(range(0 35)) /// 
       ylabel(1(1)`=_N', valuelabel angle(horizontal) labsize(small) noticks) /// 
       ytitle("") ///
       xtitle("(a) Central Gov., 2001 ", size(large)) ///
       graphregion(color(white) margin(r=2)) ///
       legend(off) ///
       name(g1, replace)



//------------------------------------------------------------------
// (3) Plot 3b: Year 2022 (Central)
//------------------------------------------------------------------

use temp,clear 
gen id=1 
keep if year==2022
drop if D_local==1 

// Count the number of IDs for each objective
collapse (sum) id_count=id, by(objective)

// Sort by count in descending order
gsort -id_count

// Calculate percentages
egen total = sum(id_count)
gen percentage = id_count / total * 100

// Generate a numeric identifier for each objective
gen objective_id = _n

// Keep the first 7 objectives
drop if objective_id > 10

// Add value labels to the x-axis
forvalues i = 1/`=_N' {
    label define objective_lbl `i' `"`=objective[`i']'"', add
}
label values objective_id objective_lbl

// Create a new variable with percentage and % sign
gen percentage_label = string(percentage, "%9.2f") + "%"


// Create the graph with percentage labels including % sign
twoway (bar id_count objective_id, barwidth(0.6) color(gs8) hori) /// 
       (scatter objective_id id_count, msymbol(none) mlabel(percentage_label) mlabposition(3) mlabsize(small) mlabcolor(black)), ///
       xlabel(0(10)30, angle(horizontal)) ///
       xscale(range(0 35)) /// 
       ylabel(1(1)`=_N', valuelabel angle(horizontal) labsize(small) noticks) /// 
       ytitle("") ///
       xtitle("(b) Central Gov., 2022 ", size(large)) ///
       graphregion(color(white) margin(r=2)) ///
       legend(off) ///
       name(g2, replace)


	   
//------------------------------------------------------------------
// (4) Plot 3c: Year 2022 (Central +local )
//------------------------------------------------------------------

use temp,clear 

gen count_local1 = (D_local == 1)
gen count_local0 = (D_local == 0)

// Focus on reporting years 
keep if year==2022

// Collapse data to get counts for each objective and D_local value
collapse (sum) count_local1 count_local0, by(objective)

// Calculate total count and sort
gen total_count = count_local1 + count_local0
gsort -total_count

// Calculate percentages
egen grand_total = sum(total_count)
gen percentage = total_count / grand_total * 100

// Generate a numeric identifier for each objective
gen objective_id = _n

// Keep the first 7 objectives
drop if objective_id > 10

// Add value labels to the x-axis
forvalues i = 1/`=_N' {
    label define objective_lbl `i' `"`=objective[`i']'"', add
}
label values objective_id objective_lbl

// Create a new variable with percentage and % sign
gen percentage_label = string(percentage, "%9.2f") + "%"

// Create the graph with stacked bars and percentage labels
twoway (bar total_count objective_id, barwidth(0.8) color(gs12) hori) ///
      (bar count_local0 objective_id, barwidth(0.8) color(gs8) hori) /// 
       (scatter objective_id total_count, msymbol(none) mlabel(percentage_label) mlabposition(3) mlabsize(medium) mlabcolor(black)), ///
    xlabel(, angle(horizontal)) ///
    ylabel(1(1)`=_N', valuelabel angle(horizontal) labsize(small) noticks) ///
    ytitle("") ///
    xtitle("(c) Central + Local, 2022 ", size(large)) ///
    graphregion(color(white) margin(r=2)) ///
    legend(off) ///
    name(g3, replace)
	
	   

graph combine g1 g2 g3, ///
    col(3) ///
    imargin(small) /// 
    graphregion(color(white) margin(l=2 r=2)) /// 
    xsize(25) ysize(9) /// 
    iscale(*1)       
	
graph export ../figs/3_combination_final.png, width(3200) height(1800) replace

cap erase temp.dta


