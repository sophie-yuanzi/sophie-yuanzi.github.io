*==============================================================================
* File name:     4-Plot.do
* Date written:  September 9, 2024
* Date revised:  April 9, 2026
*
*==============================================================================*/

clear all 
set more off 

//change the directory
pwd
cd ../data


// Keep data of local government
use subsidy_data_panel, clear 
keep if D_local == 1
keep id_policy start_year end_year year province



//------------------------------------------------------------------
// (1) Plot 4a: The replationship between subsidy numbers and GDP per capita
//------------------------------------------------------------------


// Collapse data to yearly level
collapse (count) num_policies = id_policy, by(year province)

// Only keep the policies present in the notification period
drop if year < 2015 | year > 2022

// Collapse data to province level
collapse (sum) num_policies, by(province)
replace num=num/8  //8 years average 


merge 1:1 province using ./other_data/prov_gdp_trade_10_14, keep(3) nogen 

// Adjust the data
replace GDP_per_capita = GDP_per_capita/1000
gen lgdppc = log(GDP_per_capita)
gen lnum = log(num_policies)

// Different positions for overlapped labels
local label_right `""Tibet", "Heilongjiang", "Shandong", "Tibet", "Shaanxi", "Jiangxi",  "Jilin",  "Jiangsu", "Qinghai""'

// Plot Graph
twoway (scatter lnum lgdppc  if !inlist(province, `label_right'), mlabposition(3) msize(small) mlabel(province) mlabcolor(black) mlabsize(small) mcolor(grey%20)) ///
       (scatter lnum lgdppc  if inlist(province, `label_right'), mlabposition(9) msize(small) mlabel(province) mlabcolor(black) mlabsize(small) mcolor(grey%20)) ///
       (lfit lnum lgdppc, mlabposition(3) msize(small) color(black)), ///
       ytitle("Number of Subsidies Per Year", size(large)) ///
       xtitle("GDP Per Capita (Thousand RMB)", size(large)) ///
       ylabel(0 "1" 1 "3" 2 "7" 3 "20" 4 "55") ///
       xlabel(3 "20.09" 3.5 "33.12" 4 "54.60" 4.5 "90.02" 5 "148.41", format(%9.2f) valuelabel angle(horizontal)) ///
       graphregion(fcolor(white)) ///
       legend(off) ///
       name(g1, replace)



//------------------------------------------------------------------
// (2) Plot 4b: The replationship between subsidy numbers and trade openness
//------------------------------------------------------------------

// Different positions for overlapped labels
local label_right `""Sichuan", "Guizhou", "Yunnan", "Shanxi", "Qinghai", "Shaanxi", "Anhui""'

// Plot Graph
twoway (scatter lnum trade_open  if !inlist(province, `label_right') , mlabposition(3) msize(small) mlabel(province) mlabcolor(black) mlabsize(small) mcolor(grey%20)) ///
       (scatter lnum trade_open  if inlist(province, `label_right'), mlabposition(9) msize(small) mlabel(province) mlabcolor(black) mlabsize(small) mcolor(grey%20)) ///
       (lfit lnum trade_open, mlabposition(3) msize(small) color(black)), ///
       ytitle("Number of Subsidies Per Year", size(large)) ///
       xtitle("Trade Openness", size(large)) ///
       xscale(range(-0.1 1.5)) ///
       ylabel(0 "1" 1 "3" 2 "7" 3 "20" 4 "55") ///
       xlabel(, format(%9.2f) valuelabel angle(horizontal)) ///
       graphregion(fcolor(white)) ///
       legend(off) ///
       name(g2, replace)
	   


graph combine g1 g2, ///
    col(2) ///
    imargin(vlarge) ///  
    graphregion(color(white) margin(l=2 r=2)) /// <
    xsize(20) ysize(9) /// 
    iscale(*1) ///         
	note("                                     (a) Development Level                                                                   (b) Trade Openness Level", size(medium) span margin(t=-5)) 
	
graph export ../figs/4_combination_final.png, width(3200) height(1800) replace

