*==============================================================================
* File name:     5-Plot.do
* Date written:  September 9, 2024
* Date revised:  April 9, 2026

* 
*==============================================================================*/

clear all 
set more off 

//change the directory
pwd
cd ../data


//------------------------------------------------------------------
// (1) Split the sector variable
//------------------------------------------------------------------

use subsidy_data_panel, clear 

// Split the 'objective' variable and reshape
split sector, parse(; )
keep id_policy D_local year sector*
drop sector
reshape long sector, i(id_policy D_local year) j(j)


// Clean up the data
drop if sector == ""
drop j
replace sector =strltrim(sector)
save temp, replace


//----------------------------------------------------------------------
// (2) Plot 5a: Rank of sectors by number of subsidies
//----------------------------------------------------------------------

// Generate separate count variables for D_local=1 and D_local=0
gen count_local1 = (D_local == 1)
gen count_local0 = (D_local == 0)


// Collapse data to get counts for each objective and D_local value
collapse (sum) count_local1 count_local0, by(sector)

// Calculate total count and sort
gen total_count = count_local1 + count_local0
gsort -total_count

// Calculate percentages
egen grand_total = sum(total_count)
gen percentage = total_count / grand_total * 100

// Generate a numeric identifier for each objective
gen objective_id = _n

// Add value labels to the x-axis
forvalues i = 1/`=_N' {
    label define objective_lbl `i' `"`=sector[`i']'"', add
}
label values objective_id objective_lbl

// Create a new variable with percentage and % sign
gen percentage_label = string(percentage, "%9.2f") + "%"

// Create the graph with stacked bars and percentage labels
twoway (bar total_count objective_id, barwidth(0.8) color(gs12) hori) ///
       (bar count_local0 objective_id, barwidth(0.8) color(gs8) hori) /// 
       (scatter objective_id total_count, msymbol(none) mlabel(percentage_label) mlabposition(3) mlabsize(small) mlabcolor(black)), ///
       xlabel(, angle(horizontal)) ///
       ylabel(1(1)`=_N', valuelabel angle(horizontal) labsize(small) noticks) ///  
       ytitle("") ///
       xtitle("Number of Subsidies", size(medium)) ///
       title("", size(medium)) ///
	   legend(order(2 "Central"  1 "Local")  size(small) row(1) region(lcolor(black)) pos(6)) ///
       graphregion(fcolor(white)) ///
       graphregion(margin(r=5 b=5)) ///  
       name(g1, replace)
	   
	

//----------------------------------------------------------------------
// (3)  Plot 5b: Rank of sectors by value of subsidies
//----------------------------------------------------------------------

use temp,clear 
merge m:1 id_policy year using ./subsidy_value, nogen
replace value=value/1000  //billion
// Generate separate count variables for D_local=1 and D_local=0
gen count_local1 = value*(D_local == 1)
gen count_local0 = value*(D_local == 0)


// Collapse data to get counts for each objective and D_local value
collapse (sum) count_local1 count_local0, by(sector)

// Calculate total count and sort
gen total_count = count_local1 + count_local0
gsort -total_count

// Calculate percentages
egen grand_total = sum(total_count)
gen percentage = total_count / grand_total * 100

// Generate a numeric identifier for each objective
gen objective_id = _n

// Add value labels to the x-axis
forvalues i = 1/`=_N' {
    label define objective_lbl `i' `"`=sector[`i']'"', add
}
label values objective_id objective_lbl

// Create a new variable with percentage and % sign
gen percentage_label = string(percentage, "%9.2f") + "%"

// Create the graph with stacked bars and percentage labels
twoway (bar total_count objective_id, barwidth(0.65) color(gs12) hori) /// 
       (bar count_local0 objective_id, barwidth(0.65) color(gs8) hori) /// 
       (scatter objective_id total_count, msymbol(none) mlabel(percentage_label) mlabposition(3) mlabsize(small) mlabcolor(black)), ///
       xlabel(, angle(horizontal)) ///
       ylabel(1(1)`=_N', valuelabel angle(horizontal) labsize(small) noticks) /// 
       ytitle("") ///
       xtitle("Total Values (Billion RMB)", size(medium)) ///
       legend(order(2 "Central"  1 "Local")  size(small) row(1) region(lcolor(black)) pos(6))  /// 
       graphregion(fcolor(white) margin(r=2)) /// 
       name(g2, replace)


graph combine g1 g2, ///
    col(2) ///
    imargin(medium) ///
    graphregion(color(white)) ///
    iscale(*1) ///
    note("                        (a) Number of Subsidies                                                (b) Total Values", size(medium) span) 
    
    
	
graph export ../figs/5_combination_final.png, width(3200) height(1800) replace


cap erase temp.dta

